import java.util.HashMap;

public class Main
{
    public static int currentCallStackSize;
    public static int largestCallStackSize;
    public static int steps = 0;

    //The time complexity of this function running one time is O(c) where c is the number of characters.
    //The space complexity of this function running one time is O(1) since the same amount of data is always being created.
    //Recursively, however, the call stack will grow to the size of the "permutationStringLength" variable input in the "main" function.
    public static int charCombinations(char[] characters, int spacesLeft, int minimumCharacterIndex, HashMap<String, Integer> dynamicPermutations) {
        //Check if a similar permutation has been done before
        steps++;
        String permutationsString = ""+spacesLeft+"|"+minimumCharacterIndex;
        if (dynamicPermutations.get(permutationsString) != null)
        {
            //We've already calculated the number of permutations for a branch of this size, get it from the permutations string.
            return dynamicPermutations.get(permutationsString);
        }
        //Keep track of current call stack size
        currentCallStackSize++;
        if (currentCallStackSize > largestCallStackSize)
            largestCallStackSize = currentCallStackSize;

        //Initialize permutations for this call
        int permutations = 0;

        //Are we finished building a permutation?
        if (spacesLeft > 0)
        {
            //There are still spaces left
            //Try to make a call for each allowed character
            for (int i = minimumCharacterIndex; i < characters.length; i++)
            {
                //Make a call with one less "spacesLeft"
                permutations += charCombinations(characters, spacesLeft - 1, minimumCharacterIndex, dynamicPermutations);

                //Add 1 to minimum character index for next recursive call to prevent duplicate iterations that have just been handled by the call we just made.
                minimumCharacterIndex += 1;
            }
        } else {
            //No spaces left, this is a permutation! Add 1.
            permutations += 1;
        }

        //Store
        dynamicPermutations.put(permutationsString, permutations);
        currentCallStackSize--;
        return permutations;
    }

    //The time complexity of the program is logarithmic, since the number of function calls grows at a slower and slower rate as the character set and permutation string length grow larger.
    //The space complexity of the program is O(s) where "s" is the permutationStringLength, since that also represents the lowest leaf position on the tree and the maximum size of the function call stack.
    public static void main(String[] args)
    {
        //--------------------------------------------INPUT SECTION
        char[] characterSet = {'A', 'B', 'C', 'D'}; //Set the characters to be used
        int permutationStringLength = 5; //Set the length of the permutations
        //Ex: "{'A', 'B', 'C'}" and "5" will count the permutations possible by filling 5 slots with only those characters.
        //--------------------------------------------END OF INPUT SECTION

        HashMap<String, Integer> dynamicPermutations = new HashMap<>();
        String charactersString = "{";
        for (int i = 0; i < characterSet.length; i++) {
            charactersString += characterSet[i];
            if (i < characterSet.length - 1) {
                charactersString += ", ";
            }
        }
        charactersString += "}";
        System.out.println("Character Set: " + charactersString);
        System.out.println("Length of Permutation Strings: " + permutationStringLength);
        System.out.println("Number of Permutations: "+charCombinations(characterSet, permutationStringLength, 0, dynamicPermutations));
        System.out.println("Recursive function calls: " + steps);
        System.out.println("Largest Call-Stack Size: " + largestCallStackSize);
    }
}